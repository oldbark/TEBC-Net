
echo "Head Entity Detection (HED) model, train and test the model..."
python train_detection.py --entity_detection_mode LSTM --fix_embed --gpu 0